import xlrd
wb = xlrd.open_workbook(r"/Users/wendi/Desktop/Lab/data.xlsx")
sh1 = wb.sheet_by_name('MildSteel')
sh2 = wb.sheet_by_name('Plastic')

load1 = sh1.col_values(0)
extension1 = sh1.col_values(2)
stress1 = sh1.col_values(8)
strain1 = sh1.col_values(10)

load2 = sh2.col_values(0)
extension2 = sh2.col_values(2)
stress2 = sh2.col_values(8)
strain2 = sh2.col_values(10)

import numpy
import math
import matplotlib.pyplot as plt
x1 = extension1
y1 = load1
x2 = extension2
y2 = load2

m1 = strain1
n1 = stress1
m2 = strain2
n2 = stress2

plt.title('Stress-Strain Curve(Plastic)')
plt.xlabel('Strain(%)')
plt.ylabel('Stress(MPa)')
plt.plot(m2,n2,'darkorchid')
plt.scatter(0.8012,44.3617)
plt.text(0.88,44.3617,'(0.8012,44.3617)',fontsize=10)
plt.show()