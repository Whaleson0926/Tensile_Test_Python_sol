import xlrd
import numpy
import math
import matplotlib.pyplot as plt


wb = xlrd.open_workbook(r"/Users/wendi/Desktop/Lab/data.xlsx")
sh1 = wb.sheet_by_name('MildSteel')
sh2 = wb.sheet_by_name('Plastic')

load1 = sh1.col_values(0)
extension1 = sh1.col_values(2)
stress1 = sh1.col_values(8)
strain1 = sh1.col_values(10)

load2 = sh2.col_values(0)
extension2 = sh2.col_values(2)
stress2 = sh2.col_values(8)
strain2 = sh2.col_values(10)

x1 = extension1
y1 = load1
x2 = extension2
y2 = load2

m1 = strain1
n1 = stress1
m2 = strain2
n2 = stress2

import numpy
m2_sel = strain2[:316]
n2_sel = stress2[:316]

x_bar = numpy.mean(m2_sel)
m = len(m2_sel)
sum_yx = 0
sum_x2 = 0
sum_delta = 0
for i in range(m):
    x = m2_sel[i]
    y = n2_sel[i]
    sum_yx += y*(x-x_bar)
    sum_x2 += x**2
w = sum_yx/(sum_x2-m*(x_bar**2))

for i in range(m):
    x = m2_sel[i]
    y = n2_sel[i]
    sum_delta += (y-w*x)
b = sum_delta/m

n2_pre = []
for i in m2_sel:
    n2_raw = w*i+b
    n2_pre.append(n2_raw)

s1 = list(numpy.arange(0.02,m2_sel[-1]+0.15 , 0.1))
d1 = []
for i in s1:
    raw_y = w*i+(-0.02*w)
    d1.append(raw_y) # slope = w;  intercept = -0.02*w

k = (42.2635-42.1473)/(0.754-0.7516)
h = 42.1473-k*0.7516
x3=list(numpy.linspace(0.745,0.755,10))
y3=[]
for i in x3:
    y3_raw = k*i+h
    y3.append(y3_raw)

inp_x = (h-(-0.02*w))/(w-k)
inp_y = k*inp_x+h
print(inp_x,inp_y)
plt.title('Stress-Strain Curve(Plastic)')
plt.xlabel('Strain(%)')
plt.ylabel('Stress(MPa)')
plt.plot(m2,n2,'darkorchid')
plt.plot(m2_sel,n2_pre,color='steelblue',linestyle='--')
plt.text(-0.03,40,'slope ={} GPa'.format('%.4f'%(w*100/1000)))
plt.show()