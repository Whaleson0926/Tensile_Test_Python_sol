import xlrd
wb = xlrd.open_workbook(r"/Users/wendi/Desktop/Lab/data.xlsx")
sh1 = wb.sheet_by_name('MildSteel')
sh2 = wb.sheet_by_name('Plastic')

load1 = sh1.col_values(0)
extension1 = sh1.col_values(2)
stress1 = sh1.col_values(8)
strain1 = sh1.col_values(10)

load2 = sh2.col_values(0)
extension2 = sh2.col_values(2)
stress2 = sh2.col_values(8)
strain2 = sh2.col_values(10)

import numpy
import math
import matplotlib.pyplot as plt
x1 = extension1
y1 = load1
x2 = extension2
y2 = load2

m1 = strain1
n1 = stress1
m2 = strain2
n2 = stress2


plt.title('Load-Extension Curve(MildSteel & Platsic)')
plt.xlabel('Extension(mm)')
plt.ylabel('Load(kN)')
plt.text(11.97,13.26,'MildSteel')
plt.text(1.77,2.18,'Plastic')
plt.plot(x1,y1,'olivedrab')
plt.plot(x2,y2,'dodgerblue')
plt.show()

plt.title('Stress-Strain Curve(MildSteel & Platsic)')
plt.xlabel('Strain(%)')
plt.ylabel('Stress(MPa)')
plt.text(23,430,'MildSteel')
plt.text(4,85,'Plastic')
plt.plot(m1,n1,'hotpink')
plt.plot(m2,n2,'darkorchid')
plt.show()

plt.title('Load-Extension Curve(MildSteel)')
plt.xlabel('Extension(mm)')
plt.ylabel('Load(kN)')
plt.plot(x1,y1,'olivedrab')
plt.show()


plt.title('Stress-Strain Curve(MildSteel)')
plt.xlabel('Strain(%)')
plt.ylabel('Stress(MPa)')
plt.plot(m1,n1,'hotpink')
plt.show()


plt.title('Load-Extension Curve(Plastic)')
plt.xlabel('Extension(mm)')
plt.ylabel('Load(kN)')
plt.plot(x2,y2,'dodgerblue')
plt.show()

plt.title('Stress-Strain Curve(Plastic)')
plt.xlabel('Strain(%)')
plt.ylabel('Stress(MPa)')
plt.plot(m2,n2,'darkorchid')
plt.show()
