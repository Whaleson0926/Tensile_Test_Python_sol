import xlrd
import numpy
import math
import matplotlib.pyplot as plt


wb = xlrd.open_workbook(r"/Users/wendi/Desktop/Lab/data.xlsx")
sh1 = wb.sheet_by_name('MildSteel')
sh2 = wb.sheet_by_name('Plastic')

load1 = sh1.col_values(0)
extension1 = sh1.col_values(2)
stress1 = sh1.col_values(8)
strain1 = sh1.col_values(10)

load2 = sh2.col_values(0)
extension2 = sh2.col_values(2)
stress2 = sh2.col_values(8)
strain2 = sh2.col_values(10)

x1 = extension1
y1 = load1
x2 = extension2
y2 = load2

m1 = strain1
n1 = stress1
m2 = strain2
n2 = stress2

import numpy
m1_sel = strain1[:317]
n1_sel = stress1[:317]
x_bar = numpy.mean(m1_sel)
m = len(m1_sel)
sum_yx = 0
sum_x2 = 0
sum_delta = 0
for i in range(m):
    x = m1_sel[i]
    y = n1_sel[i]
    sum_yx += y*(x-x_bar)
    sum_x2 += x**2
w = sum_yx/(sum_x2-m*(x_bar**2))

for i in range(m):
    x = m1_sel[i]
    y = n1_sel[i]
    sum_delta += (y-w*x)
b = sum_delta/m

n1_pre = []
for i in m1_sel:
    n1_raw = w*i+b
    n1_pre.append(n1_raw)

s1 = list(numpy.arange(0.02,2.5, 0.1))
d1 = []
for i in s1:
    raw_y = w*i+(-0.02*w)
    d1.append(raw_y) # slope = w;  intercept = -0.02*w

k = (350.027-349.0641)/(0.1148-0.1228)
h = 350.027-k*0.1148
x3=list(numpy.linspace(0.02,0.13,10))
y3=[]
for i in x3:
    y3_raw = k*i+h
    y3.append(y3_raw)

low_section = stress1[547:947]
inp_y = min(low_section)
inp_x = strain1[stress1.index(inp_y)]

inp_y_list = []
for i in s1:
    inp_y_list.append(inp_y)

plt.title('Stress-Strain Curve(MildSteel)')
plt.xlabel('Strain(%)')
plt.ylabel('Stress(MPa)')
plt.plot(m1,n1,'hotpink')

plt.plot(s1,inp_y_list,color='blueviolet',linestyle=':')
plt.scatter(inp_x,inp_y,color='red')
plt.text(inp_x,inp_y+0.5,'({},{})'.format('%.4f'%inp_x,'%.4f'%inp_y))
plt.show()


    