from cProfile import label
from statistics import mean
from tkinter import font
import xlrd
wb = xlrd.open_workbook(r"/Users/wendi/Desktop/Lab/data.xlsx")
sh1 = wb.sheet_by_name('MildSteel')
sh2 = wb.sheet_by_name('Plastic')

load1 = sh1.col_values(0)
extension1 = sh1.col_values(2)
stress1 = sh1.col_values(8)
strain1 = sh1.col_values(10)

load2 = sh2.col_values(0)
extension2 = sh2.col_values(2)
stress2 = sh2.col_values(8)
strain2 = sh2.col_values(10)

import numpy
import math
import matplotlib.pyplot as plt
x1 = extension1
y1 = load1
x2 = extension2
y2 = load2

m1 = strain1
n1 = stress1
m2 = strain2
n2 = stress2

plt.title('Stress-Strain Curve(MildSteel)')
plt.xlabel('Strain(%)')
plt.ylabel('Stress(MPa)')
plt.plot(m1,n1,'hotpink')
plt.scatter(0.0944,344.8325,10)
plt.text(0.095,344,'(0.0944,344.8325,10)',fontsize=15)
plt.show()
